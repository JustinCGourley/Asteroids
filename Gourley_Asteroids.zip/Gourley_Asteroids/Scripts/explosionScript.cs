﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class explosionScript : MonoBehaviour {

	private Sprite[] sprites;
	public int tick = 0, animationState = 0, pick = 0;
	public int[] animationTick = {10, 10, 10};

	// Use this for initialization
	void Start () {
		//get a random explosion spritesheet
		string[] randomPath = {"explosion_2", "explosion_3" };

		pick = Random.Range (0, randomPath.Length);
		//setup sprite sheet to be used
		Sprite[] spritesGet = Resources.LoadAll<Sprite>(randomPath [pick]);
		sprites = spritesGet;
		//set initial picture to first sprite
		gameObject.GetComponent<SpriteRenderer> ().sprite = sprites [0];
		animationState = 0;
		tick = 0;


		int randomScale = Random.Range (3, 8);
		transform.localScale = new Vector3(randomScale, randomScale, 0);

	}
	
	// Update is called once per frame
	void Update () {
		tick++;
		if (tick >= animationTick[pick]) {
			tick = 0;

			animationState++;
			if (animationState >= sprites.Length) {
				Destroy (gameObject);
			} 
			else {
				gameObject.GetComponent<SpriteRenderer> ().sprite = sprites [animationState];
			}
		}
	}
}
