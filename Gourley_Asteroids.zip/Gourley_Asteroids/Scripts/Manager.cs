﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.IO;

public class Manager : MonoBehaviour {

    public GameObject missile;
    public GameObject shipFab;
    public GameObject asteroidBig, asteroidMed, asteroidSmall;
	public GameObject explosion;
	public GameObject particles;

	private GameObject ship;
	private List<GameObject> missiles;
	private List<GameObject> asteroids;
	private List<int> asteroidType;
    
    private ShipScript shipScript;

	public int maxMissiles = 5, curMissiles = 0;
	private int score, lives, iFrames, coolDown, selectorIndex, fireCoolDown, gameOverCooldown;
	public Texture livesTexture;
	private bool gameOver, newHighScore;
	private string previous;

	// Use this for initialization
	void Start () {

		ship = Instantiate (shipFab);

        shipScript = ship.GetComponent<ShipScript>();
		missiles = new List<GameObject>();
		asteroids = new List<GameObject> ();
		asteroidType = new List<int> ();

		fireCoolDown = 0;
		gameOver = false;
		coolDown = 200;
		score = 0;
		lives = 3;
		selectorIndex = 0;
		curMissiles = 0;
		gameOverCooldown = 0;
    }

	/// <summary>
	/// Reads the highscores file and returns its contents
	/// </summary>
	/// <returns>The file.</returns>
	string[] ReadFile()
	{
		
		string path = Application.dataPath + "/highscores.txt";
		string[] scores = new string[10];

		for (int i = 0; i < 10; i++) {
			scores [i] = "-----";
		}

		StreamReader reader = new StreamReader (path);
		for (int i = 0; i < 10; i++) 
		{
			string line = reader.ReadLine ();
			if (line == null)
			{
				i = 10;
			}
			else 
			{
				scores [i] = line;
			}
		}
		reader.Close ();

		return scores;
	}

	void WriteToFile(string[] scores)
	{
		string path = Application.dataPath + "/highscores.txt";

		StreamWriter writer = new StreamWriter (path, false);
		for (int i = 0; i < 10; i++) {
			writer.WriteLine (scores [i]);
		}
		writer.Close ();
	}

	/// <summary>
	/// Check to see if the high score should be updated
	/// </summary>
	bool UpdateHighScores()
	{
		string[] scores = ReadFile();

		int[] amounts = new int[10];
		bool found = false;

		//change the strings into int's and see if the highscore list should be updated
		for (int i = 0; i < 10; i++)
		{

			if (found)
			{
				string newPrev = scores [i];
				scores [i] = previous;
				previous = newPrev;
			} 
			else 
			{
				int.TryParse (scores [i], out amounts [i]);

				if (amounts [i] < score) 
				{
					previous = scores [i];
					scores [i] = "" + score;
					found = true;
				}
			}
		}

		WriteToFile (scores);

		return found;
	}
	
	// Update is called once per frame
	void Update () {
		if (!gameOver) 
		{
			GameUpdate ();
		}
		else
		{
			if (gameOverCooldown != 0)
			{
				return;
			}
			if (Input.GetKeyDown(KeyCode.UpArrow))
			{
				selectorIndex = 0;
			}
			else if (Input.GetKeyDown(KeyCode.DownArrow))
			{
				selectorIndex = 1;
			}
			else if (Input.GetKeyDown(KeyCode.Space))
			{
				if (selectorIndex == 0)
				{
					lives = 3;
					gameOver = false;

					//remove any remaining asteroids
					if (asteroids.Count > 0) {
						for (int i = 0; i < asteroids.Count; i++) {
							Destroy (asteroids [i]);
						}
					}

					Start ();
				}
				else if (selectorIndex == 1) 
				{
					SceneManager.LoadScene ("Menu", LoadSceneMode.Single);
				}
			}
		}
	}

	/// <summary>
	/// Update the game
	/// </summary>
	void GameUpdate()
	{
		if (fireCoolDown != 0) {
			fireCoolDown--;
		}
		if (Input.GetKeyDown(KeyCode.Space) && (curMissiles < maxMissiles) && fireCoolDown == 0)
		{
			fireCoolDown = 10;
			curMissiles++;
			GameObject missileMake = Instantiate(missile, shipScript.position, shipScript.transform.rotation);
			missileMake.GetComponent<missileScript>().SetMissile(shipScript.position, shipScript.direction, shipScript.transform.rotation);
			missiles.Add (missileMake);
		}

		CheckMissiles ();
		CheckMissileCollisions ();

		//dont check collisions if player has invicibility frames
		if (iFrames == 0) 
		{
			CheckPlayerCollisions ();
		}

		CheckComplete ();

		//update players alpha value when iFrames are active
		if (iFrames > 0 ) {
			iFrames-=1;
			int change = 2;
			if (coolDown != 200) {
				change = 6;
			}
			if (iFrames % change == 0) 
			{
				float shipAlpha = ship.GetComponent<SpriteRenderer> ().color.a;
				if (shipAlpha == 0.2f) {
					shipAlpha = 1f;
				} else {
					shipAlpha = 0.2f;
				}

				if (iFrames == 0) {
					shipAlpha = 1;
				}
				ship.GetComponent<SpriteRenderer> ().color = new Color (1f, 1f, 1f, shipAlpha);
			}
		}
	}

	/// <summary>
	/// Manage GUI Objects, as well as the Game over menu
	/// </summary>
	void OnGUI()
	{
		//display in-game GUI
		if (!gameOver) {

			GUIStyle guiStyle = new GUIStyle (GUI.skin.label);
			guiStyle.fontSize = 40;
			
			GUI.Label (new Rect (10, 10, 700, 100), ("Score: " + score), guiStyle);

			for (int i = 0; i < lives; i++) {
				GUI.Label (new Rect ((i * 40) + 30, 60, 30, 40), livesTexture);
			}
		}

		//display game-over screen
		if (gameOver) 
		{	
			float width = Screen.width;
			float height = Screen.height;
			GUIStyle style = new GUIStyle (GUI.skin.label);
			style.fontSize = 80;
			style.alignment = TextAnchor.MiddleCenter;

			GUI.Label (new Rect ((width/2) - 400, 30, 800, 200), "Game Over", style);

			//delay the end game screen/options
			if (gameOverCooldown != 0) 
			{
				gameOverCooldown--;
				return;
			}
	
			//score
			style.fontSize = 60;
			GUI.Label (new Rect ((width/2) - 300, (height/2) - 100, 600, 100), "Score: " + score, style);


			style.fontSize = 40;
			//display 'new high score' if the score is higher than any on the top 10 list
			if (newHighScore) 
			{
				GUI.Label (new Rect ((width/2) + 300, (height/2) - 100, 400, 100), "- New High Score!", style);
			}

			//options
			GUI.Label (new Rect ((width/2) - 200, (height/2) + 50, 400, 100), "Retry", style);
			GUI.Label (new Rect ((width/2) - 200, (height/2) + 150, 400, 100), "Main Menu", style);
			//selector
			GUI.Label (new Rect ((width/2) - 250, (height/2) + 50 + (selectorIndex * 100), 50, 100), ">", style);
		}

	}

	/// <summary>
	/// Check to see if new asteroids should be spawned in
	/// </summary>
	void CheckComplete()
	{
		//no asteroids left, generate new ones
		if (asteroids.Count <= 0) 
		{
			if (coolDown != 0) {
				if (coolDown == 200) 
				{
					iFrames = 400;
				}

				coolDown--;
				return;
			}

			coolDown = 200;
			int count = Random.Range (3, 6);

			for (int i = 0; i < count; i++) {

				//spawn in random asteroid
				//large asteroid - 60% chance to spawn
				//medium asteroid - 30% chance to spawn
				//small asteroid - 10% chance to spawn
				int type = Random.Range (0, 10);

				float screenWidth = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width, 0, 0)).x;
				float screenHeight = Camera.main.ScreenToWorldPoint(new Vector3(0, Screen.height, 0)).y;
				float x = Random.Range (-screenWidth/2, screenWidth/2);
				float y = Random.Range (-screenHeight/2, screenHeight/2);

				Vector3 asteroidSpawnPos = new Vector3 (x, y, 0);

				GameObject asteroidObj;
				int asteroidObjType;

				if (type >= 4) 
				{
					asteroidObj = Instantiate (asteroidBig, asteroidSpawnPos, new Quaternion(0, 0, 0, 0));
					asteroidObjType = 3;
				} 
				else if (type >= 1) 
				{
					asteroidObj = Instantiate (asteroidMed, asteroidSpawnPos, new Quaternion(0, 0, 0, 0));
					asteroidObjType = 2;
				} 
				else 
				{
					asteroidObj = Instantiate (asteroidSmall, asteroidSpawnPos, new Quaternion(0, 0, 0, 0));
					asteroidObjType = 1;
				}

				//add in asteroids to list
				asteroids.Add(asteroidObj);
				asteroidType.Add (asteroidObjType);

			}

		}
	}

	/// <summary>
	/// checks collisions for player's ship to see if it has hit an asteroid
	/// </summary>
	void CheckPlayerCollisions()
	{
		float shipRadius = ship.GetComponent<SpriteRenderer> ().bounds.extents.x;
		Vector3 shipCenter = ship.transform.position;

        for (int i = 0; i < asteroids.Count; i++) {
			GameObject asteroid = asteroids [i];

			float radius = asteroid.GetComponent<SpriteRenderer> ().bounds.extents.x / 3;
			Vector3 center = asteroid.transform.position;
            Vector3 distance = shipCenter - center;

            if (distance.magnitude < (radius + shipRadius))
			{
				Instantiate (explosion, ship.transform.position, new Quaternion(0,0,0,0));
                //player is hit, give iframes and set position to center
                ship.GetComponent<SpriteRenderer> ().color = new Color(1f, 1f, 1f, 0.5f);
				ship.GetComponent<ShipScript> ().velocity = new Vector3 (0, 0, 0);
				ship.transform.position = new Vector3 (0, 0, 0);
				iFrames = 210;
				lives--;
				if (lives <= 0) {
					gameOver = true;
					gameOverCooldown = 300;
					Destroy (ship);
					newHighScore = UpdateHighScores ();
				}
			}
		}
	}

	/// <summary>
	/// Checks to see if a missile obj should be removed from the missiles array
	/// </summary>
	void CheckMissiles()
	{
		for (int i = 0; i < missiles.Count; i++) {
			//if missile no longer exists, remove it from the list
			if (missiles[i] == null) {
				missiles.RemoveAt (i);
				curMissiles--;
			}
		}
	}

	/// <summary>
	/// checks to see if a missile collides with an object
	/// </summary>
	void CheckMissileCollisions()
	{
		//go through each missile
		for (int i = 0; i < missiles.Count; i++) {
			GameObject obj = missiles [i];

			Bounds objBounds = obj.GetComponent<SpriteRenderer> ().bounds;

			//go through all the asteroids
			for (int j = 0; j < asteroids.Count; j++) {
				GameObject asteroid = asteroids [j];

				float radius = asteroid.GetComponent<SpriteRenderer> ().bounds.extents.x / 3;
				Vector3 center = asteroid.transform.position;

				//check collisions
				if (((Mathf.Abs (center.x - objBounds.min.x) <= radius) || (Mathf.Abs (center.x - objBounds.max.x) <= radius)) //x axis collision
				    && ((Mathf.Abs (center.y - objBounds.min.y) <= radius) || (Mathf.Abs (center.y - objBounds.max.y) <= radius))) //y axis collision
				{
					DestroyAsteroid (j);

					//destroy missile that hit the asteroid
					Destroy(obj);
					missiles.RemoveAt (i);
					curMissiles--;
					//set the asteroid loop variable to max so it wont keep looking for asteroids to hit
					j = asteroids.Count;
					Instantiate (explosion, obj.transform.position, obj.transform.rotation);
				} 


			}
		}
	}

	void DestroyAsteroid(int asteroidIndex)
	{
		if (asteroidType[asteroidIndex] == 3) 
		{
			Vector3 pos = asteroids[asteroidIndex].transform.position;
			Quaternion rot = asteroids[asteroidIndex].transform.rotation;
			Vector3 direction = asteroids [asteroidIndex].GetComponent<asteroidBigScript> ().direction;

			//destroy old asteroids
			Destroy (asteroids[asteroidIndex]);
			asteroids.RemoveAt (asteroidIndex);
			asteroidType.RemoveAt (asteroidIndex);

			//create 2 medium asteroids
			GameObject medAsteroid1 = Instantiate (asteroidMed, pos, rot);
			GameObject medAsteroid2 = Instantiate (asteroidMed, pos, rot);

			//set direction of new asteroids relative to the old one
			Vector3 ranDirection = new Vector3 (direction.x + Random.Range(-0.2f, 0.2f), direction.y + Random.Range(-0.1f, 0.1f), 0);
			medAsteroid1.GetComponent<asteroidMedScript> ().direction = ranDirection;

			ranDirection = new Vector3 (direction.x + Random.Range(-0.2f, 0.2f), direction.y + Random.Range(-0.1f, 0.1f), 0);
			medAsteroid2.GetComponent<asteroidMedScript> ().direction = ranDirection;

			//add in asteroids
			asteroids.Add (medAsteroid1);
			asteroids.Add (medAsteroid2);
			asteroidType.Add (2);
			asteroidType.Add (2);
			//add score
			score += 20;
		} 
		else if (asteroidType[asteroidIndex] == 2) 
		{
			Vector3 pos = asteroids[asteroidIndex].transform.position;
			Quaternion rot = asteroids[asteroidIndex].transform.rotation;
			Vector3 direction = asteroids [asteroidIndex].GetComponent<asteroidMedScript> ().direction;

			//destroy old asteroids
			Destroy (asteroids[asteroidIndex]);
			asteroids.RemoveAt (asteroidIndex);
			asteroidType.RemoveAt (asteroidIndex);

			//create 2 small asteroids
			GameObject smallAsteroid1 = Instantiate (asteroidSmall, pos, rot);
			GameObject smallAsteroid2 = Instantiate (asteroidSmall, pos, rot);

			//set direction of new asteroids relative to the old one
			Vector3 ranDirection = new Vector3 (direction.x + Random.Range(-0.2f, 0.2f), direction.y + Random.Range(-0.1f, 0.1f), 0);
			smallAsteroid1.GetComponent<asteroidSmallScript> ().direction = ranDirection;

			ranDirection = new Vector3 (direction.x + Random.Range(-0.2f, 0.2f), direction.y + Random.Range(-0.1f, 0.1f), 0);
			smallAsteroid2.GetComponent<asteroidSmallScript> ().direction = ranDirection;

			//add in asteroids
			asteroids.Add (smallAsteroid1);
			asteroids.Add (smallAsteroid2);
			asteroidType.Add (1);
			asteroidType.Add (1);
			//add score
			score += 50;
		} 
		else 
		{
			//destroy old asteroids
			Destroy (asteroids[asteroidIndex]);
			asteroids.RemoveAt (asteroidIndex);
			asteroidType.RemoveAt (asteroidIndex);
			//add score
			score += 20;
		}
	}

}
