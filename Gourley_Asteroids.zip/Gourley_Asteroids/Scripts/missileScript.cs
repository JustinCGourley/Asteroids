﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class missileScript : MonoBehaviour {

    private float lifeSpan;
    public Vector3 position;
	private Vector3 direction, velocity;
    private float maxSpeed;
	private float screenWidth, screenHeight;

	// Use this for initialization
	void Start () {
		screenWidth = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width, 0, 0)).x;
		screenHeight = Camera.main.ScreenToWorldPoint(new Vector3(0, Screen.height, 0)).y;
	}

    /// <summary>
    /// setup missile's direction and initial position
    /// </summary>
    /// <param name="point"></param>
    /// <param name="pointTowards"></param>
	public void SetMissile(Vector3 point, Vector3 pointTowards, Quaternion rotation)
    {
		//setup missile attributes
        position = point;
        direction = pointTowards;
		transform.rotation = rotation;

		//defaults
		lifeSpan = 10f;
		maxSpeed = 0.3f;

		//setup velocity of bullet based on attributes
		velocity = direction;
		velocity = Vector3.ClampMagnitude (velocity, maxSpeed);

    }
	
    /// <summary>
    /// update movement of missile
    /// </summary>
	void FixedUpdate () {
		
        position += velocity;
        transform.position = position;
		lifeSpan -= velocity.magnitude;
		//set fade color
		float fadeSpan = (lifeSpan / 15f);
		Color fade = gameObject.GetComponent<SpriteRenderer> ().color;
		fade.a = fadeSpan;
		//set fade
		gameObject.GetComponent<SpriteRenderer>().color = fade;

		//destroy the bullet after its gone past its lifespan
		if (lifeSpan <= 0) {
			Destroy (gameObject);
		}

		ScreenWrap ();
	}


	/// <summary>
	/// Prevent the ship from moving off the screen
	/// </summary>
	void ScreenWrap()
	{
		float offSet = 0.1f;
		//screen wrap on x-axis
		if (position.x <= -(screenWidth + offSet)) 
		{
			position.x = screenWidth + offSet;
		}
		else if (position.x >= (screenWidth + offSet)) 
		{
			position.x = -(screenWidth + offSet);
		}
		//screen wrap on y-axis
		if (position.y <= -(screenHeight + offSet)) 
		{
			position.y = screenHeight + offSet;
		}
		else if (position.y >= (screenHeight + offSet)) 
		{
			position.y = -(screenHeight + offSet);
		}

		transform.position = position;
	}

}
