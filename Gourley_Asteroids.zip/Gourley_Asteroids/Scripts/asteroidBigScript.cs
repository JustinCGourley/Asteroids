﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class asteroidBigScript : MonoBehaviour {

	public Sprite[] sprites;	
	private float rotationSpeed;
	private float rotation;
	private Vector3 velocity, position;
	private float screenWidth, screenHeight;
	public Vector3 direction;

	// Set-up asteroid rotation speed, starting angle, and sprite picture
	void Start () {

		position = transform.position;

		//set-up the speed of this asteroid based on the rotMin and rotMax
		float rotMax = 0.1f;
		float rotMin = 0.03f;
		rotationSpeed = Random.Range (rotMin, rotMax);

		//start the asteroid at a random rotation
		rotation = Random.Range (0, 360);

		//determine if it should spin the the left or right
		if (Random.Range (0, 2) == 1) {
			rotationSpeed = -rotationSpeed;
		}

		//change the sprite of the asteroid into a random one of the 3
		int ranSprite = Random.Range (0, sprites.Length);
		GetComponent<SpriteRenderer> ().sprite = sprites [ranSprite];

		//set up speed of asteroid and direction
		float speedMin = 0.02f;
		float speedMax = 0.04f;
		float speed = Random.Range (speedMin, speedMax);

		direction = new Vector3 (Random.Range (-1f, 1f), Random.Range (-1f, 1f), 0);
		velocity = direction * speed;

		screenWidth = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width, 0, 0)).x;
		screenHeight = Camera.main.ScreenToWorldPoint(new Vector3(0, Screen.height, 0)).y;
	}

	// rotate the asteroid
	void Update () {

		Move ();
		ScreenWrap ();

		rotation += rotationSpeed;
		transform.rotation = Quaternion.Euler(0, 0, rotation);
	}

	/// <summary>
	/// Move the asteroid
	/// </summary>
	void Move()
	{
		position += velocity;
		transform.position = position;
	}	

	/// <summary>
	/// Prevent the ship from moving off the screen
	/// </summary>
	void ScreenWrap()
	{
		float offSet = 1.3f;
		//screen wrap on x-axis
		if (position.x <= -(screenWidth + offSet)) 
		{
			position.x = screenWidth + offSet;
		}
		else if (position.x >= (screenWidth + offSet)) 
		{
			position.x = -(screenWidth + offSet);
		}
		//screen wrap on y-axis
		if (position.y <= -(screenHeight + offSet)) 
		{
			position.y = screenHeight + offSet;
		}
		else if (position.y >= (screenHeight + offSet)) 
		{
			position.y = -(screenHeight + offSet);
		}

		transform.position = position;
	}

	void FixedUpdate()
	{

	}

}
