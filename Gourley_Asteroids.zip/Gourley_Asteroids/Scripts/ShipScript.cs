﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShipScript : MonoBehaviour {

	public GameObject missile;
	public float rotateSpeed = 5f;
	public float acceleration = 0.005f;
	public float maxSpeed = 0.15f;
	public float rotation, screenWidth, screenHeight;
	public Vector3 velocity, accelerationVec;
    public Vector3 direction, position;
	public GameObject engineObj;
	private ParticleSystem engine;

	// Use this for initialization
	void Start () {
		//initilize variables
		rotation = 0;
		velocity = Vector3.zero;
		direction = new Vector3 (0, 1, 0);
		accelerationVec = Vector3.zero;
		position = transform.position;

		screenWidth = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width, 0, 0)).x;
		screenHeight = Camera.main.ScreenToWorldPoint(new Vector3(0, Screen.height, 0)).y;

		engine = engineObj.GetComponent<ParticleSystem> ();
		engine.Stop();

	}
	
	// Update is called once per frame
	void Update () {
		ShipMovement ();
		ScreenWrap ();

		CheckCollision ();
	}

	/// <summary>
	/// Updates the ship's rotation and velocity based on user input
	/// </summary>
	void ShipMovement()
	{
		//check to see if ship's position has been set elsewhere
		if (position != gameObject.transform.position) {
			position = gameObject.transform.position;
		}


		//update ship rotation based on input
		if (Input.GetKey (KeyCode.LeftArrow)) 
		{
			rotation += rotateSpeed;
			direction = Quaternion.Euler (0, 0, rotateSpeed) * direction;
		}
		else if (Input.GetKey (KeyCode.RightArrow)) 
		{
			rotation -= rotateSpeed;
			direction = Quaternion.Euler (0, 0, -rotateSpeed) * direction;
		}
		transform.rotation = Quaternion.Euler(0, 0, rotation);

		//get input for ship acceleration
		if (Input.GetKey (KeyCode.UpArrow)) {
			accelerationVec = direction * acceleration;
			velocity += accelerationVec;

			velocity = Vector3.ClampMagnitude (velocity, maxSpeed);
			engine.Play();
		} 
		else {
			velocity /= 1.1f;
			if (velocity.magnitude < 0.00001f) {
				velocity = Vector3.zero;
			}
			engine.Stop ();
		}

		position += velocity;
		transform.position = position;
	}

	/// <summary>
	/// Prevent the ship from moving off the screen
	/// </summary>
	void ScreenWrap()
	{
		float offSet = 0.4f;
		//screen wrap on x-axis
		if (position.x <= -(screenWidth + offSet)) 
		{
			position.x = screenWidth + offSet;
		}
		else if (position.x >= (screenWidth + offSet)) 
		{
			position.x = -(screenWidth + offSet);
		}
		//screen wrap on y-axis
		if (position.y <= -(screenHeight + offSet)) 
		{
			position.y = screenHeight + offSet;
		}
		else if (position.y >= (screenHeight + offSet)) 
		{
			position.y = -(screenHeight + offSet);
		}

		transform.position = position;
	}

	void CheckCollision()
	{
		//GetComponent<SpriteRenderer> ().color = new Color (255, 0, 0);
	}
}
