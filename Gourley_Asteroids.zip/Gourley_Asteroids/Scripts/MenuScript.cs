﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.IO;

public class MenuScript : MonoBehaviour {

    string selector;
    int selectIndex = 0;
	bool viewHighScore;
	string[] scores;

	// Use this for initialization
	void Start () {
        selector = ">  ";
        selectIndex = 0;
		viewHighScore = false;
		scores = new string[10];
		ReadFile ();
	}

	/// <summary>
	/// Read the highscores file
	/// </summary>
	void ReadFile()
	{
		string path = Application.dataPath + "/highscores.txt";

		for (int i = 0; i < 10; i++) {
			scores [i] = "-----";
		}

		StreamReader reader = new StreamReader (path);
		for (int i = 0; i < 10; i++) 
		{
			string line = reader.ReadLine ();
			if (line == null)
			{
				i = 10;
			}
			else 
			{
				scores [i] = line;
			}
		}
		reader.Close ();
	}

	/// <summary>
	/// Displays the on-screen text
	/// </summary>
    void OnGUI()
    {

        float screenWidth = Screen.width;
        float screenHeight = Screen.height;


		//-----------
		//High Scores
		//-----------
		if (viewHighScore)
		{
			//set style for text
			GUIStyle styleHS = new GUIStyle(GUI.skin.label);
			styleHS.fontSize = 50;
			styleHS.alignment = TextAnchor.MiddleLeft;

			//display the scores loaded from file
			for (int i = 0; i < 10; i++) 
			{
				string seperator = ":        ";
				if (i == 9)
					seperator = ":      ";
				GUI.Label(new Rect((screenWidth/2) - 100, 200 + (i * 50), 400, 100), (i + 1) + seperator + scores[i], styleHS);
			}

			//display the button
			styleHS.alignment = TextAnchor.MiddleCenter;
			GUI.Label(new Rect((screenWidth / 2) - 200, screenHeight - 200, 400, 200), ">   Main Menu", styleHS);

			//display the title
			styleHS.fontSize = 80;
			styleHS.alignment = TextAnchor.MiddleCenter;
			GUI.Label(new Rect((screenWidth / 2) - 400, 20, 800, 200), "High Scores", styleHS);

			return;
		}

		//---------
		//Main Menu
		//---------

        //show which option is selected
        string start = "Start Game", highscore = "High Scores", quit = "Quit";

        //set style for text
        GUIStyle style = new GUIStyle(GUI.skin.label);
        style.fontSize = 50;
        style.alignment = TextAnchor.MiddleCenter;

        //show text
        GUI.Label(new Rect((screenWidth / 2) - 200, (screenHeight / 1.5f) - 150, 400, 100), start, style);
		GUI.Label(new Rect((screenWidth / 2) - 200, (screenHeight / 1.5f) - 50, 400, 100), highscore, style);
        GUI.Label(new Rect((screenWidth / 2) - 200, (screenHeight / 1.5f) + 50, 400, 100), quit, style);
        GUI.Label(new Rect((screenWidth / 2) - 350, (screenHeight / 1.5f) - 150 + (selectIndex * 100), 150, 100), selector, style);


        style.fontSize = 100;
        GUI.Label(new Rect((screenWidth / 2) - 400, 150, 800, 150), "Asteroids", style);
    }

	// Update is called once per frame
	void Update () {
		//run only this if statement if they are viewing high-scores
		if (viewHighScore) {

			//return to main menu
			if (Input.GetKeyDown (KeyCode.Space)) {
				viewHighScore = false;
			}

			return;
		}

        //change menu options
		if (Input.GetKeyDown(KeyCode.UpArrow) && selectIndex != 0)
        {
            selectIndex--;
        }
        else if (Input.GetKeyDown(KeyCode.DownArrow) && selectIndex != 2)
        {
            selectIndex++;
        }
        //select menu option
        if (Input.GetKeyDown(KeyCode.Space))
        {
            //start game
            if (selectIndex == 0)
            {
				SceneManager.LoadScene ("game", LoadSceneMode.Single);
            }
			//go to high scores
			if (selectIndex == 1) 
			{
				viewHighScore = true;
			}
            //quit game
            else if (selectIndex == 2)
            {
                Application.Quit();
            }
        }
	}
}
